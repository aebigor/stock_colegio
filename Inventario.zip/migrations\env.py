from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool
import app.models
from app.modules.auth.models import *
from app.modules.configuracion.model import *
from app.modules.categorias.model import *
from app.modules.activos.model import *
from app.modules.personas.model import *
from app.modules.activos.movimiento_model import *
from app.modules.mantenimientos.model import *

from alembic import context

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
from app.core.database import Base

target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    
    # IMPORTANTE: Importamos tus configuraciones de Pydantic
    from app.core.config import settings
    
    # Obtenemos la sección de configuración de alembic.ini
    configuration = config.get_section(config.config_ini_section, {})
    if configuration is None:
        configuration = {}
        
    # SOBREESCRIBIMOS la URL del .ini con tu DATABASE_URL real del .env
    configuration["sqlalchemy.url"] = settings.DATABASE_URL

    connectable = engine_from_config(
        configuration,  # <-- Usamos el diccionario modificado aquí
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection, 
            target_metadata=target_metadata
        )

        with context.begin_transaction():
            context.run_migrations()



if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
