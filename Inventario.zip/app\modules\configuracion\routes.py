from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import hash_password, verify_password
from app.core.templates import templates
from app.modules.auth.dependencies import get_current_user, require_super_admin, require_empresa_superadmin_principal
from app.modules.auth.models import Usuario
from .schema import ConfiguracionCreate
from .service import ConfiguracionService

router = APIRouter(
    prefix="/configuracion",
    tags=["Configuración"],
    dependencies=[Depends(get_current_user)],
)


@router.get("/")
def index(
    request: Request,
    _actor: Usuario = Depends(require_super_admin),
    db: Session = Depends(get_db),
):
    configuracion = ConfiguracionService(db).obtener()
    return templates.TemplateResponse(
        request=request,
        name="configuracion/index.html",
        context={"title": "Configuración", "configuracion": configuracion, "puede_cambiar_password": bool(getattr(request.state, "es_superadmin_principal", False))},
    )


@router.post("/guardar")
def guardar(
    nombre_colegio: str = Form(...),
    abreviatura: str = Form(...),
    formato_codigo: str = Form("{PREFIJO}_{COLEGIO}_{CONSECUTIVO}"),
    longitud_consecutivo: int = Form(6),
    separador: str = Form("_"),
    _actor: Usuario = Depends(require_super_admin),
    db: Session = Depends(get_db),
):
    nombre_colegio = nombre_colegio.strip()
    abreviatura = abreviatura.strip().upper()
    separador = separador.strip() or "_"
    if not nombre_colegio or not abreviatura:
        raise HTTPException(status_code=400, detail="El nombre del colegio y la abreviatura son obligatorios.")
    if not 1 <= longitud_consecutivo <= 12:
        raise HTTPException(status_code=400, detail="La longitud del consecutivo debe estar entre 1 y 12.")
    if len(separador) > 2:
        raise HTTPException(status_code=400, detail="El separador puede tener máximo 2 caracteres.")

    datos = ConfiguracionCreate(
        nombre_colegio=nombre_colegio,
        abreviatura=abreviatura,
        formato_codigo=formato_codigo.strip() or "{PREFIJO}_{COLEGIO}_{CONSECUTIVO}",
        longitud_consecutivo=longitud_consecutivo,
        separador=separador,
    )
    service = ConfiguracionService(db)
    service.guardar(datos)
    return RedirectResponse(url="/configuracion", status_code=303)


@router.post("/cambiar-password")
def cambiar_password(
    request: Request,
    password_actual: str = Form(...),
    password_nueva: str = Form(...),
    confirmar_password: str = Form(...),
    actor: Usuario = Depends(require_empresa_superadmin_principal),
    db: Session = Depends(get_db),
):
    """Cambio de contraseña solo para el Super Admin principal de la empresa."""
    if not verify_password(password_actual, actor.password):
        return RedirectResponse(url="/configuracion?password_error=actual", status_code=303)
    if len(password_nueva) < 10:
        return RedirectResponse(url="/configuracion?password_error=corta", status_code=303)
    if password_nueva != confirmar_password:
        return RedirectResponse(url="/configuracion?password_error=confirmacion", status_code=303)
    if password_actual == password_nueva:
        return RedirectResponse(url="/configuracion?password_error=igual", status_code=303)

    actor.password = hash_password(password_nueva)
    db.commit()
    return RedirectResponse(url="/configuracion?password_actualizada=1", status_code=303)
